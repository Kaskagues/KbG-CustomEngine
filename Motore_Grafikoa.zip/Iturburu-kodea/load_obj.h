#ifndef READ_OBJ_H
#define	READ_OBJ_H

#include "definitions.h"

int read_wavefront(char * file_name, object3d * object_ptr);

#endif	/* READ_OBJ_H */

